export WRF_DIR=../../../WRFV3
export WRF_DIR_PRE=/c/WPS/geogrid/src/
export UP_ONE=../

